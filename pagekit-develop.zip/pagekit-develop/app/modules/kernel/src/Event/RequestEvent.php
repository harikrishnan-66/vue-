<?php

namespace Pagekit\Kernel\Event;

class RequestEvent extends KernelEvent
{
    use ResponseTrait;
}
