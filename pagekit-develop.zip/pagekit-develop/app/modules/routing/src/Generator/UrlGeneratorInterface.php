<?php

namespace Pagekit\Routing\Generator;

interface UrlGeneratorInterface
{
    /**
     * Generates a link url.
     */
    const LINK_URL = 'link';
}
