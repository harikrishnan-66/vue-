<?php

namespace Pagekit\Filesystem\Exception;

interface ExceptionInterface {}
