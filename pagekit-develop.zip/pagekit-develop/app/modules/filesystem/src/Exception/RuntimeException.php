<?php

namespace Pagekit\Filesystem\Exception;

class RuntimeException extends \RuntimeException implements ExceptionInterface {}
